package com.boat;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
/**
 * Reto 5 - Backend Boat informes
 * @author Ruben Hernan Ramirez Castillo - G13
 */
@SpringBootApplication
public class BoatApplication {
    /**
     * Método que inicializa la aplicacion
     * @param args
     */
    public static void main(String[] args) {
        SpringApplication.run(BoatApplication.class, args);
    }
}