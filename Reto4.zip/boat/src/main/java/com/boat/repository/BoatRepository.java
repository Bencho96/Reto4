package com.boat.repository;
import com.boat.model.Boat;
import com.boat.repository.crud.BoatCrudRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;
/**
 * Reto 5 - Backend Boat informes
 * @author Ruben Hernan Ramirez Castillo - G13
 */
@Repository
public class BoatRepository {
    /**
     * Inyector de dependencias
     */
    @Autowired
    private BoatCrudRepository boatCrudRepository;
    /**
     * @return Contiene la interfaz que extiende de JPA para que el metodo que lista todos los elementos se conecte a la base de datos
     */
    public List<Boat> getAll(){
        return (List<Boat>) boatCrudRepository.findAll();
    }
    /**
     * @param id Contiene la interfaz que extiende de JPA para que el metodo que lista un solo elemento se conecte a la base de datos
     * @return 
     */
    public Optional<Boat> getBoat(int id){
        return boatCrudRepository.findById(id);
    }
    /**
     * @param boat Contiene la interfaz que extiende de JPA para que el metodo que crea un nuevo registro se conecte a la base de datos
     * @return 
     */
    public Boat save(Boat boat){
        return boatCrudRepository.save(boat);
    }
    /**
     * @param boat Contiene la interfaz que extiende de JPA para que el metodo que borra un elemento se conecte a la base de datos
     */
    public void delete(Boat boat){
        boatCrudRepository.delete(boat);
    }
}