package com.boat.repository;
import com.boat.model.Admin;
import com.boat.repository.crud.AdminCrudRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;
/**
 * Reto 5 - Backend Boat informes
 * @author Ruben Hernan Ramirez Castillo - G13
 */
@Repository
public class AdminRepository {
    /**
     * Inyector de dependencias
     */
    @Autowired
    private AdminCrudRepository adminCrudRepository;
    /**
     * @return Contiene la interfaz que extiende de JPA para que el metodo que lista todos los elementos se conecte a la base de datos
     */
    public List<Admin> getAll(){
        return (List<Admin>) adminCrudRepository.findAll();
    }
    /**
     * @param id Contiene la interfaz que extiende de JPA para que el metodo que lista un solo elemento se conecte a la base de datos
     * @return 
     */
    public Optional<Admin> getAdmin(int id){
        return adminCrudRepository.findById(id);
    }
    /**
     * @param admin Contiene la interfaz que extiende de JPA para que el metodo que crea un nuevo registro se conecte a la base de datos
     * @return 
     */
    public Admin save(Admin admin){
        return adminCrudRepository.save(admin);
    }
    /**
     * @param admin Contiene la interfaz que extiende de JPA para que el metodo que borra un elemento se conecte a la base de datos
     */
    public void delete(Admin admin){
        adminCrudRepository.delete(admin);
    }
}