package com.boat.repository;
import com.boat.model.Reservation;
import com.boat.repository.crud.ReservationCrudRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;
/**
 * Reto 5 - Backend Boat informes
 * @author Ruben Hernan Ramirez Castillo - G13
 */
@Repository
public class ReservationRepository {
    /**
     * Inyector de dependencias
     */
    @Autowired
    private ReservationCrudRepository reservationCrudRepository;
    /**
     * @return Contiene la interfaz que extiende de JPA para que el metodo que lista todos los elementos se conecte a la base de datos
     */
    public List<Reservation> getAll(){
        return (List<Reservation>) reservationCrudRepository.findAll();
    }
    /**
     * @param id Contiene la interfaz que extiende de JPA para que el metodo que lista un solo elemento se conecte a la base de datos
     * @return 
     */
    public Optional<Reservation> getReservation(int id){
        return reservationCrudRepository.findById(id);
    }
    /**
     * @param reservation Contiene la interfaz que extiende de JPA para que el metodo que crea un nuevo registro se conecte a la base de datos
     * @return 
     */
    public Reservation save(Reservation reservation){
        return reservationCrudRepository.save(reservation);
    }
    /**
     * @param reservation Contiene la interfaz que extiende de JPA para que el metodo que borra un elemento se conecte a la base de datos
     */
    public void delete(Reservation reservation){
        reservationCrudRepository.delete(reservation);
    }
}