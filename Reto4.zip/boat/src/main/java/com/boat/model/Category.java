package com.boat.model;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import javax.persistence.*;
import java.io.Serializable;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
/**
 * Reto 5 - Backend Boat informes
 * @author Ruben Hernan Ramirez Castillo - G13
 */
@Entity
@Table(name = "category")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Category implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    /**
     * Identificador de la categoria
     */
    private Integer id;
    /**
     * Nombre de la categoria
     */
    private String name;
    /**
     * Descripcion de la categoria
     */
    private String description;
    /**
     * Modelo relacional de muchos a uno entre Categoria y Bote
     */
    @OneToMany(cascade = {CascadeType.PERSIST},mappedBy= "category")
    @JsonIgnoreProperties("category")
    private List<Boat> boats;
}