package com.boat.model;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
/**
 * Reto 5 - Backend Boat informes
 * @author Ruben Hernan Ramirez Castillo - G13
 */
@Entity
@Table(name = "reservation")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Reservation implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    /**
     * Identificador de la reserva
     */
    private Integer idReservation;
    /**
     * Fecha inicial de la reserva
     */
    private Date startDate;
    /**
     * Fecha final de la reserva
     */
    private Date devolutionDate;
    /**
     * Estado de la reserva
     */
    private String status="created";
    /**
     * Modelo relacional de muchos a uno entre Reserva y Bote
     */
    @ManyToOne
    @JoinColumn(name = "boatId")
    @JsonIgnoreProperties("reservations")
    private Boat boat;
    /**
     * Modelo relacional de muchos a uno entre Reserva y Clientes
     */
    @ManyToOne
    @JoinColumn(name = "clientId")
    @JsonIgnoreProperties({"reservations","messages"})
    private Client client;
    /**
     * Modelo relacional de uno a uno entre Reserva y Puntuacion
     */
    @OneToOne(cascade = {CascadeType.REMOVE},mappedBy="reservation")
    @JsonIgnoreProperties("reservation")
    private Score score;
}