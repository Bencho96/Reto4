package com.boat.model;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import javax.persistence.*;
import java.io.Serializable;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
/**
 * Reto 5 - Backend Boat informes
 * @author Ruben Hernan Ramirez Castillo - G13
 */
@Entity
@Table(name = "message")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Message implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    /**
     * Identificador del mensaje
     */
    private Integer idMessage;
    /**
     * Texto del mensaje
     */
    private String messageText;
    /**
     * Modelo relacional de muchos a uno entre Mensaje y Botes
     */
    @ManyToOne
    @JoinColumn(name="boatId")
    @JsonIgnoreProperties({"messages","reservations"})
    private Boat boat;
    /**
     * Modelo relacional de muchos a uno entre Mensaje y Reserva
     */
    @ManyToOne
    @JoinColumn(name="clientId")
    @JsonIgnoreProperties({"messages","reservations"})
    private Client client;
}