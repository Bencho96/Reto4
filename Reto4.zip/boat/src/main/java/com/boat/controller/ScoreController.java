package com.boat.controller;
import com.boat.model.Score;
import com.boat.service.ScoreService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Optional;
import org.springframework.http.HttpStatus;
/**
 * Reto 5 - Backend Boat informes
 * @author Ruben Hernan Ramirez Castillo - G13
 */
@RestController
@RequestMapping("/Score")
@CrossOrigin(origins = "*", methods= {RequestMethod.GET,RequestMethod.POST,RequestMethod.PUT,RequestMethod.DELETE})
public class ScoreController {
    /**
     * Inyector de dependencias
     */
    @Autowired
    private ScoreService scoreService;
    /**
     * @return Método que llama o solicita el servicio que lista los elementos de la base de datos
     */
    @GetMapping("/all")
    public List<Score> getServices(){
        return scoreService.getAll();
    }
    /**
     * @param scoreId
     * @return Método que llama o solicita el servicio que lista un elemento especeifico de la base de datos
     */
    @GetMapping("/{id}")
    public Optional<Score> getService(@PathVariable("id") int scoreId) {
        return scoreService.getScore(scoreId);
    }
    /**
     * @param score
     * @return Método que llama o solicita el servicio que crea un nuevo registro en la base de datos
     */
    @PostMapping("/save")
    @ResponseStatus(HttpStatus.CREATED)
    public Score save(@RequestBody Score score) {
        return scoreService.save(score);
    }
    /**
     * @param id
     * @return Método que llama o solicita el servicio que borra un elemento de la base de datos
     */
    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public boolean deleteScore(@PathVariable int id) {
        return scoreService.deleteScore(id);
    }
    /**
     * @param score
     * @return Método que llama o solicita el servicio que edita un elemento de la base de datos
     */
    @PutMapping("/update")
    @ResponseStatus(HttpStatus.CREATED)
    public Score updateScore(@RequestBody Score score) {
        return scoreService.update(score);
    }
}