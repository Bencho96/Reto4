package com.boat.controller;
import com.boat.model.Reservation;
import com.boat.service.ReservationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Optional;
import org.springframework.http.HttpStatus;
/**
 * Reto 5 - Backend Boat informes
 * @author Ruben Hernan Ramirez Castillo - G13
 */
@RestController
@RequestMapping("/Reservation")
@CrossOrigin(origins = "*", methods = {RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT, RequestMethod.DELETE})
public class ReservationController {
    /**
     * Inyector de dependencias
     */
    @Autowired
    private ReservationService reservationService;
    /**
     * @return Método que llama o solicita el servicio que lista los elementos de la base de datos
     */
    @GetMapping("/all")
    public List<Reservation> getReservations() {
        return reservationService.getAll();
    }
    /**
     * @param id
     * @return Método que llama o solicita el servicio que lista un elemento especeifico de la base de datos
     */
    @GetMapping("/{id}")
    public Optional<Reservation> getReservation(@PathVariable int id){
        return reservationService.getReservation(id);
    }
    /**
     * @param reservation
     * @return Método que llama o solicita el servicio que crea un nuevo registro en la base de datos
     */
    @PostMapping("/save")
    @ResponseStatus(HttpStatus.CREATED)
    public Reservation save(@RequestBody Reservation reservation) {
        return reservationService.save(reservation);
    }
    /**
     * @param id
     * @return Método que llama o solicita el servicio que borra un elemento de la base de datos
     */
    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public boolean deleteReservation(@PathVariable int id) {
        return reservationService.deleteReservation(id);
    }
    /**
     * @param reservation
     * @return Método que llama o solicita el servicio que edita un elemento de la base de datos
     */
    @PutMapping("/update")
    @ResponseStatus(HttpStatus.CREATED)
    public Reservation updateReservation(@RequestBody Reservation reservation) {
        return reservationService.updateReservation(reservation);
    }
}