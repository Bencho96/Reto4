package com.boat.service;
import com.boat.model.Client;
import com.boat.repository.ClientRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;
/**
 * Reto 5 - Backend Boat informes
 * @author Ruben Hernan Ramirez Castillo - G13
 */
@Service
public class ClientService {
    /**
     * Inyector de dependencias
     */
    @Autowired
    private ClientRepository clientRepository;
    /**
     * @return Servicio que lista los elementos de la base de datos
     */
    public List<Client> getAll() {
        return clientRepository.getAll();
    }
    /**
     * @param clientId
     * @return Servicio que lista un elemento especeifico de la base de datos
     */
    public Optional<Client> getClient(int clientId) {
        return clientRepository.getClient(clientId);
    }
    /**
     * @param client
     * @return Servicio que crea un nuevo registro en la base de datos
     */
    public Client save(Client client) {
        if (client.getIdClient() == null) {
            return clientRepository.save(client);
        } else {
            Optional<Client> e = clientRepository.getClient(client.getIdClient());
            if (e.isEmpty()) {
                return clientRepository.save(client);
            } else {
                return client;
            }
        }
    }
    /**
     * @param id
     * @return Servicio que borra un elemento de la base de datos
     */
    public boolean deleteClient(int id){
        Optional<Client> miCliente = clientRepository.getClient(id);
        if (miCliente.isEmpty()){
            return false;
        }else{
            clientRepository.delete(miCliente.get());
            return true;
        }
    }
    /**
     * @param client
     * @return Servicio que edita un elemento de la base de datos
     */
    public Client updateClient(Client client){
        if (client.getIdClient()!=null){
            Optional<Client> cliente = clientRepository.getClient(client.getIdClient());
            if (!cliente.isEmpty()){
               if (client.getName()!=null){
                   cliente.get().setName(client.getName());
               }
               if (client.getEmail()!=null){
                   cliente.get().setEmail(client.getEmail());
               }
               if (client.getPassword()!=null){
                   cliente.get().setPassword(client.getPassword());
               }
               if (client.getAge()!=null){
                   cliente.get().setAge(client.getAge());
               }
               return clientRepository.save(cliente.get());
            }else{
               return client;
            }
        }
        return client;     
    }
}