package com.boat.service;
import com.boat.model.Message;
import com.boat.repository.MessageRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;
/**
 * Reto 5 - Backend Boat informes
 * @author Ruben Hernan Ramirez Castillo - G13
 */
@Service
public class MessageService {
    /**
     * Inyector de dependencias
     */
    @Autowired
    private MessageRepository messageRepository;
    /**
     * @return Servicio que lista los elementos de la base de datos
     */
    public List<Message> getAll() {
        return messageRepository.getAll();
    }
    /**
     * @param messageId
     * @return Servicio que lista un elemento especifico de la base de datos
     */
    public Optional<Message> getMessage(int messageId) {
        return messageRepository.getMessage(messageId);
    }
    /**
     * @param message
     * @return Servicio que crea un nuevo registro en la base de datos
     */
    public Message save(Message message) {
        if (message.getIdMessage() == null) {
            return messageRepository.save(message);
        } else {
            Optional<Message> e = messageRepository.getMessage(message.getIdMessage());
            if (e.isEmpty()) {
                return messageRepository.save(message);
            } else {
                return message;
            }
        }
    }
    /**
     * @param id
     * @return Servicio que borra un elemento de la base de datos
     */
    public boolean deleteMessage(int id) {
        Optional<Message> miMensaje = messageRepository.getMessage(id);
        if (miMensaje.isEmpty()) {
            return false;
        } else {
            messageRepository.delete(miMensaje.get());
            return true;
        }
    }
    /**
     * @param message
     * @return Servicio que edita un elemento de la base de datos
     */
    public Message updateMessage(Message message) {
        if (message.getIdMessage() != null) {
            Optional<Message> mensaje = messageRepository.getMessage(message.getIdMessage());
            if (!mensaje.isEmpty()) {
                if (message.getMessageText() != null) {
                    mensaje.get().setMessageText(message.getMessageText());
                }
                return messageRepository.save(mensaje.get());
            } else {
                return message;
            }
        }
        return message;
    }
}