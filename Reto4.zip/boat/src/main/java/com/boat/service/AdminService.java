package com.boat.service;
import com.boat.model.Admin;
import com.boat.repository.AdminRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;
/**
 * Reto 5 - Backend Boat informes
 * @author Ruben Hernan Ramirez Castillo - G13
 */
@Service
public class AdminService {
    /**
     * Inyector de dependencias
     */
    @Autowired
    private AdminRepository adminRepository;
    /**
     * @return Servicio que lista los elementos de la base de datos
     */
    public List<Admin> getAll() {
        return adminRepository.getAll();
    }
    /**
     * @param adminId
     * @return Servicio que lista un elemento especeifico de la base de datos
     */
    public Optional<Admin> getAdmin(int adminId) {
        return adminRepository.getAdmin(adminId);
    }
    /**
     * @param admin
     * @return Servicio que crea un nuevo registro en la base de datos
     */
    public Admin save(Admin admin) {
        if (admin.getIdAdmin() == null) {
            return adminRepository.save(admin);
        } else {
            Optional<Admin> admin1 = adminRepository.getAdmin(admin.getIdAdmin());
            if (admin1.isEmpty()) {
                return adminRepository.save(admin);
            } else {
                return admin;
            }
        }
    }
    /**
     * @param id
     * @return Servicio que borra un elemento de la base de datos
     */
    public boolean deleteAdmin(int id) {
        Optional<Admin> admin = adminRepository.getAdmin(id);
        if (admin.isEmpty()) {
            return false;
        } else {
            adminRepository.delete(admin.get());
            return true;
        }
    }
    /**
     * @param admin
     * @return Servicio que edita un elemento de la base de datos
     */
    public Admin updateAdmin(Admin admin) {
        if (admin.getIdAdmin()!= null) {
            Optional<Admin> user = adminRepository.getAdmin(admin.getIdAdmin());
            if (!user.isEmpty()) {
                if (admin.getName() != null) {
                    user.get().setName(admin.getName());
                }
                if (admin.getEmail() != null) {
                    user.get().setEmail(admin.getEmail());
                }
                if (admin.getPassword()!= null) {
                    user.get().setPassword(admin.getPassword());
                }
                return adminRepository.save(user.get());
            } else {
                return admin;
            }
        }
        return admin;
    }
}